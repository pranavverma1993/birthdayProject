import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-snow',
  templateUrl: './snow.component.html',
  styleUrls: ['./snow.component.css']
})
export class SnowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
