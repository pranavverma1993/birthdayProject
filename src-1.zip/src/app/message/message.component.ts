import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.css']
})
export class MessageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


// setTimeout(()=>this.showContent=true, 1000);
// setTimeout(()=>this.showContent=false, 3000);
// setTimeout(()=>this.showContent1=true, 4000);
// setTimeout(()=>this.showContent1=false, 6000);
// setTimeout(()=>this.showContent2=true, 7000);
// setTimeout(()=>this.showContent2=false, 9000);
// setTimeout(()=>this.showContent3=true, 10000);
// setTimeout(()=>this.showContent3=false, 12000);



}
